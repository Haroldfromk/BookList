//
//  Int+Extension.swift
//  Book
//
//  Created by Dongik Song on 5/6/24.
//

import Foundation

extension Int {
    var stringValue: String? {
        return String(self)
    }
}

extension Int64 {
    var stringValue: String? {
        return String(self)
    }
}
