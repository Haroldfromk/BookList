//
//  WishVM.swift
//  Book
//
//  Created by Dongik Song on 5/7/24.
//

import UIKit
import CoreData
import Combine


class WishVM {
    
    let context = (UIApplication.shared.delegate as! AppDelegate) .persistentContainer.viewContext
    let request: NSFetchRequest<WishListModel> = WishListModel.fetchRequest()
    
    private var cancellables = Set<AnyCancellable>()
    
    @Published var wishDocument = [WishListModel]()
    
    func saveDocumentToCoredata (data: Document) {
        
        let newItem = WishListModel(context: context)
        newItem.title = data.title
        newItem.author = data.authors[0]
        newItem.content = data.contents
        newItem.image = data.thumbnail
        newItem.price = Int64(data.price)
        
        do {
            try context.save()
            print("담기 완료")
        } catch {
            
        }
        
    }
    
    func getDocumentfromCoreData () {
        do {
            try context.fetch(request).publisher.flatMap { data in
                Publishers.Sequence(sequence: [data])
            }
            .collect()
            .eraseToAnyPublisher()
            .assign(to: \.wishDocument, on: self)
            .store(in: &cancellables)
        } catch {
            
        }
        
    }
    
    func getSpecificData (title: String) {
        let predicateRequest: NSFetchRequest<WishListModel> = WishListModel.fetchRequest()
        let predicate = NSPredicate(format: "title == %@", title)
        predicateRequest.predicate = predicate
        
        do {
            try context.fetch(predicateRequest).publisher.flatMap { data in
                Publishers.Sequence(sequence: [data])
            }
            .collect()
            .eraseToAnyPublisher()
            .assign(to: \.wishDocument, on: self)
            .store(in: &cancellables)
        } catch {
            
        }
    }
    
    func checkDuplicate (title: String) -> Bool {
        
        var flag = false
        getSpecificData(title: title)
        
        if wishDocument.isEmpty {
            flag = false
        } else {
            flag = true
        }
        return flag
    }
    
    func deleteAllData () {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "WishListModel")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
        } catch {
            
        }
    }
    
    func deleteSpeificData (selectedCell: NSManagedObject) {
        do {
            try context.delete(selectedCell)
            try context.save()
        } catch {
            
        }
        
    }
}

