//
//  Secret.swift
//  Book
//
//  Created by Dongik Song on 5/5/24.
//

import Foundation

class Secret {
    
    static let apikey = "b8509612a92687e22c9a8221d882c972"
    
}
